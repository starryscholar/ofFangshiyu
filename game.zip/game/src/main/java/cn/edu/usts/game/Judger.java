package cn.edu.usts.game;

/**
 * Created by 11616 on 2020/4/2.
 */

public class Judger {


    int getResult(int value1,int value2,Person person,Computer computer){

        int i =value1-value2;
        if(i==2||i==-1) {
            person.setScore(person.getScore()+1);
            return 1;//person win
        }
        else if(i==1||i==-2) {
            computer.setScore(computer.getScore()+1);
            return 2;//computer win
        }
        else {

            return  0;//all win
        }
    }

}
