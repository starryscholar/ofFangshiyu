package cn.edu.usts.game;



/**
 * Created by 11616 on 2020/4/2.
 */

public interface Player {
    String name = "";
    int score = 0;
    int play(int i);
}
