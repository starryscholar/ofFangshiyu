package cn.edu.usts.moocwork13;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    private List<String> dataList = new ArrayList();

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.rv);
        initData();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        MyAdapter adapter = new MyAdapter(this, dataList);
        recyclerView.setAdapter(adapter);

        recyclerView.addItemDecoration(new DividerItemDecoration(this, new DividerItemDecoration.OnGroupListener() {
            @Override
            public String getGroupName(int position) {
                return dataList.get(position).substring(0, 1);
            }
        }));

    }

    private void initData() {
        dataList.add("方世玉");
        dataList.add("方大同");
        dataList.add("陈陈");
        dataList.add("陈世美");
        dataList.add("大帅比");
        dataList.add("张小凡");
        dataList.add("张大帅比");
        dataList.add("老巢咖啡");
        dataList.add("老妪");
        dataList.add("辰大水");
        dataList.add("深度学习");
        dataList.add("深深");
        dataList.add("深且不易");
        dataList.add("华仔");
        dataList.add("华容道");
        dataList.add("学友哥");
        dataList.add("学个屁");
        dataList.add("包大人");
        dataList.add("包青天");
        dataList.add("包你满意");

        dataList.add("天生我才必有用");
        dataList.add("天生我才给你点用");
        dataList.add("硬币哥");
        dataList.add("硬水");



        Collections.sort(dataList);

    }


//    public static void start(Context context) {
//        Intent intent = new Intent(context, RecyclerViewActivity.class);
//        context.startActivity(intent);
//    }
}


