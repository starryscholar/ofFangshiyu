package cn.edu.usts.moocwork13;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * Created by 11616 on 2020/4/11.
 */

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView tv;
    public MyViewHolder(View itemView) {
        super(itemView);
        tv = (TextView) itemView.findViewById(R.id.recycle_tv);
        tv.setTextSize(25);
    }
}
