package cn.edu.usts.moocwork25;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner spinner1,spinner2;
    ArrayAdapter arrayAdapter1,arrayAdapter2;
    WebView webView;
    TextView tv ;
    String content;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message message) {

            super.handleMessage(message);
            switch (message.what) {
                case 1000:
                    webView.setVisibility(View.VISIBLE);
                    webView.loadDataWithBaseURL("",content,"text/html","UTF-8","");

                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

    }
    private void initView() {
        spinner1 = (Spinner) this.findViewById(R.id.spinner1);
        spinner2 = (Spinner) this.findViewById(R.id.spinner2);
        webView = (WebView) this.findViewById(R.id.webview);
        //数据
        List<String> data_list = new ArrayList<>();
        data_list.add("江苏");
        data_list.add("山东");
        data_list.add("湖北");
        data_list.add("湖南");
        data_list.add("安徽");

        //适配器 系统默认布局  android.R.layout.simple_spinner_item
        // 可以自定义
        arrayAdapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, data_list);


        spinner1.setAdapter(arrayAdapter1);



        //里面item点击监听 默认选择第一个
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0 :
                        List<String> data_list = new ArrayList<>();
                        data_list.add("南京");
                        data_list.add("盐城");
                        data_list.add("苏州");
                        arrayAdapter2 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_item, data_list);
                        spinner2.setAdapter(arrayAdapter2);
                        break;
                    case 1 :
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        new Thread(){
                            @Override
                            public void run() {
                                Connect("http://www.weather.com.cn/weather1d/101190101.shtml");

                            }
                        }.start();
                        Log.i("MyTest","Connect线程执行");

                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    void Connect(String path) {

        try {
            Log.i("MyTest","WebView Load111111111");
            URL url = new URL(path);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestMethod("GET");

            if(conn.getResponseCode()!=200) {
                Log.i("MyTest","请求失败!");
                throw new RuntimeException("请求失败!");

            }

            InputStream is = conn.getInputStream();
            byte[] data = read(is);
            String html = new String(data,"UTF-8");
            content = html;
            is.close();
            conn.disconnect();
            handler.sendEmptyMessage(1000);

        } catch (MalformedURLException e) {
            Log.i("MyTest","111111111111111");
            e.printStackTrace();
        } catch (IOException e) {
            Log.i("MyTest","222222222222222");
            e.printStackTrace();
        } catch (Exception e) {
            Log.i("MyTest","33333333333333");
            e.printStackTrace();
        }

    }
    public byte[] read(InputStream is) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len = 0;
        while (( len = is.read(buffer))!=-1){
            out.write(buffer,0,len);
        }
        is.close();
        return out.toByteArray();
    }

}
